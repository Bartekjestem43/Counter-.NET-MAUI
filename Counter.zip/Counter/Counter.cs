﻿namespace Counter
{
    public class Counter
    {
        public string Name { get; set; }
        public int Value { get; set; }
        public int StartValue { get; set; }
        public string Color { get; set; }
    }
}
